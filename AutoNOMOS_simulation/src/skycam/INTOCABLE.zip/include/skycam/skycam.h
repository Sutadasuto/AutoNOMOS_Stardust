#ifndef SKYCAM
#define SKYCAM

#include <ros/ros.h>
#include <ros/package.h>
#include <cmath>

#include <math.h> 
#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */

#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include "opencv2/opencv.hpp"
#include <iostream>

#include "sensor_msgs/LaserScan.h"
#include <tf/transform_datatypes.h>
#include <tf/tf.h>
#include "tf2_msgs/TFMessage.h" //sonar
#include "std_msgs/Float32.h"

using namespace cv;
using namespace std;

class skycam
{

//private:
public:

	ros::NodeHandle nh_;
	
  	image_transport::ImageTransport it_;
  	image_transport::Subscriber sky_image_;
	ros::Subscriber laser_;
	ros::Subscriber pose_;
	ros::Publisher velocity_;
	ros::Publisher steering_;

	Mat sky_image;
	
	cv_bridge::CvImagePtr cv_ptr_1;	

	//Image segmentation
	Mat lab;
	Mat labChannels[3];
	Mat lChannel, aChannel, bChannel;	
	Mat car;
	Mat map;	
	Mat laserMap;
	float scale;
	float resizeScale;

	//Handle Mouse
	Point goal;
	bool flag1;
	

	// Path planning
	float minCurve;
	Mat path;
	int flag;
	Point position;
	float angle;
	int beam;
	vector<int> indices;
	vector<Point> route;
	vector<Point> newPoints;

	// Control
	int p1, p2;
	float direction;
	tf::Vector3 axis;
	tf::Quaternion q;
	tf::Matrix3x3 R;
	tf::Vector3 positionVector, originVector, goalVector;
	float errorVelocity, errorSteering;
	float IerrorVelocity, IerrorSteering;
	float Pv, Iv, Dv, Ps, Is, Ds;
	float speedLimit;
	float velRange, steerRange;
	int errorTolerance;
	std_msgs::Float32 velocity;
	std_msgs::Float32 steering;
	
public:
	skycam();
	~skycam();
	
	void skyImage(const sensor_msgs::ImageConstPtr &msg);
	void readLaser(const sensor_msgs::LaserScan &msg);
	vector<Point> RRT(Mat analyzedMap, Mat analyzedCar, Point goal, int beam, float scale, float angle);		
	void getAttitude(const tf2_msgs::TFMessage &msg);
	Point getPosition(Mat carMap);
	vector<Point> smoothPath(Mat analyzedMap, vector<Point> path);

private:
	static void onMouseStatic( int event, int x, int y, int flags, void* point );
	void onMouse( int event, int x, int y, int flags );
};

#endif
