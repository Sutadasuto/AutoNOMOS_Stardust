# POMDP_tools
Python script that shows the output of a POMDP modeled for autonomous driving.
At the left the states are shown while on the right the observations.

## Usage
Normal usage:
´´´
./grid.py -f FILE
´´´

To get help:
´´´
./grid.py -h
´´´

