http://gazebosim.org/tutorials?tut=ros_depth_camera&cat=connect_ros
