#ifndef SKYCAM
#define SKYCAM

#include <ros/ros.h>
#include <ros/package.h>
#include <cmath>

#include <math.h> 
#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */

#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include "opencv2/opencv.hpp"
#include <iostream>

#include "sensor_msgs/LaserScan.h"
#include <tf/transform_datatypes.h>
#include <tf/tf.h>
#include "tf2_msgs/TFMessage.h" //sonar

using namespace cv;
using namespace std;

class skycam
{

//private:
public:

	ros::NodeHandle nh_;
	
  	image_transport::ImageTransport it_;
  	image_transport::Subscriber sky_image_;
	ros::Subscriber laser_;
	ros::Subscriber pose_;

	Mat sky_image;
	
	cv_bridge::CvImagePtr cv_ptr_1;	

	//Image segmentation
	Mat lab;
	Mat labChannels[3];
	Mat lChannel, aChannel, bChannel;
	Mat car;
	Mat map;	
	Mat laserMap;
	float scale;

	//Handle Mouse
	Point goal;
	bool flag1;
	
	Mat path;
	int flag;
	Point position;
	float angle;	
	
public:
	skycam();
	~skycam();
	
	void skyImage(const sensor_msgs::ImageConstPtr &msg);
	void readLaser(const sensor_msgs::LaserScan &msg);
	Mat RRT(Mat map, Point goal, float scale, Point position, float angle);		
	void getAttitude(const tf2_msgs::TFMessage &msg);

private:
	static void onMouseStatic( int event, int x, int y, int flags, void* point );
	void onMouse( int event, int x, int y, int flags );
	void getPosition(Mat carMap);
};

#endif
