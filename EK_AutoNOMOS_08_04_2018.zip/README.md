# EK_AutoNOMOS
Eagle Knights development for AutoNOMOS mini Simulation

## Gazebo Plugin
Plugin for controlling the autonomos mini


## AutoNOMOS simulation
Files for using the simulation of the autonomos  


